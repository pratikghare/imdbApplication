import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms'
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { MovieHomeComponent } from './movie-home/movie-home.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { MoviesListComponent } from './movies-list/movies-list.component';
import { ActorDetailsComponent } from './actor-details/actor-details.component';
import { ActorsListComponent } from './actors-list/actors-list.component';
import { TvsListComponent } from './tvs-list/tvs-list.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { NewnavbarComponent } from './newnavbar/newnavbar.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { TvDetailsComponent } from './tv-details/tv-details.component';

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    LoginComponent,
    RegisterComponent,
    ForgotPasswordComponent,
    MovieHomeComponent,
    MovieDetailsComponent,
    MoviesListComponent,
    ActorDetailsComponent,
    ActorsListComponent,
    TvsListComponent,
    AccountDetailsComponent,
    NewnavbarComponent,
    PagenotfoundComponent,
    TvDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
