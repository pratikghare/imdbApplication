import { Component, OnInit } from '@angular/core';
import { faStar } from '@fortawesome/free-solid-svg-icons';
import { DataService } from '../datashare/data.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-actor-details',
  templateUrl: './actor-details.component.html',
  styleUrls: ['./actor-details.component.css']
})
export class ActorDetailsComponent implements OnInit {

  constructor(private myRouter: Router, 
    private http : HttpClient, 
    public ds : DataService) { }

  public faStar = faStar
  
  ngOnInit(): void {
  }

  public dataObject = {
    mainTitle : "",
    titleYear : "",
    genre : "",
    releaseDate : "",
    imdbRating : "",
    imdbVotes : "",
    posterLink : "",
    videoLink : "",
    titlePlot : "",
    metaScore : "",
    rottenTomatoes : "",
    awardsReceived : "",
    directors : "",
    writers : "",
    runtime : "",
    cast : [ ]
  }
  private OMDB_baseURL = "http://www.omdbapi.com/?apikey=f9ecc56a&"
  private TMDB_api_key = "?api_key=e22a6668d441f9ca846239c727eb615e"
  private posterBaseURL = "https://image.tmdb.org/t/p/w500"
  private youtubeBaseURL = "https://www.youtube.com/embed/"
  private TMDB_baseURL = "https://api.themoviedb.org/3"

  
  public movieId = ""
  private movieSearch = {
    byMovie : "/search/movie",
    byID : "/movie/",
    byPersonID : "/person/",
    byTVID : "",
    byActor : "/search/person?api_key=",
    byTV : "/search/tv",
    similarMovie : "/movie/"+"/similar",
    topRated : "/movie/top_rated",
    upCommingMovies : "/movie/upcoming",
    nowPlaying : "/movie/now_playing"
  }

  navigateTo(page){
    this.myRouter.navigate([page])
  }

  async getMovieDetails(id){
    this.movieId = id
    const url = this.TMDB_baseURL + this.movieSearch.byID + this.movieId +  this.TMDB_api_key
    const movieListObj : any = await this.http.get(url).toPromise();
    console.log(movieListObj)
    console.log(url)
    await this.setDataFromTMDB(movieListObj)
    console.log(this.dataObject)
    this.ds.shareMovieDetails(this.dataObject)
    this.navigateTo('movie-details')
  }

  async setDatafromOMDB(movieListObj){
    //Getting IMDb Movie ID
    const extIDURL = this.TMDB_baseURL + this.movieSearch.byID + this.movieId + "/external_ids" + this.TMDB_api_key
    const extIDResult = await this.http.get(extIDURL).toPromise()
    const imdbID = extIDResult["imdb_id"]
    //Getting Movie Details from OMDB
    const userOMDBurl = this.OMDB_baseURL + "i=" + imdbID
    const omdbDATA : any= await this.http.get(userOMDBurl).toPromise()
    //console.log('OMDB DATA')
    //console.log(omdbDATA)

    //IMDB RATING
    this.dataObject.imdbRating = omdbDATA.Ratings[0].Value.split('/')[0];
    //console.log(this.dataObject.imdbRating)
    //IMDB VOTES
    this.dataObject.imdbVotes = omdbDATA.imdbVotes;
    //console.log(this.dataObject.imdbVotes)
    //PLOT
    if(omdbDATA.Plot != "N/A")
      this.dataObject.titlePlot = omdbDATA.Plot;
    //console.log(this.dataObject.titlePlot)
    //META SCORE
    if(omdbDATA.Metascore != "N/A")
      this.dataObject.metaScore = omdbDATA.Metascore;
    //console.log(this.dataObject.metaScore)
    //ROTTEN TOMATOES
    if(omdbDATA.Ratings.length>1)
      this.dataObject.rottenTomatoes = omdbDATA.Ratings[1].Value;
    //console.log(this.dataObject.rottenTomatoes)
    //AWARDS RECEIVED
    if(omdbDATA.Awards != "N/A")
      this.dataObject.awardsReceived = omdbDATA.Awards;
    //console.log(this.dataObject.awardsReceived)
    if(omdbDATA.Director != "N/A")
      this.dataObject.directors = omdbDATA.Director;
    if(omdbDATA.Writer != "N/A")
      this.dataObject.writers = omdbDATA.Writer;
    if(omdbDATA.Runtime != "N/A")
      this.dataObject.runtime = omdbDATA.Runtime;
    if(omdbDATA.Released != "N/A")
      this.dataObject.releaseDate = omdbDATA.Released;
    console.log('ALL DATA SET')
  }

  async getCast(){
    const creditURL = this.TMDB_baseURL+this.movieSearch.byID+ this.movieId +"/credits"+this.TMDB_api_key;
    const creditsOBJ : any = await this.http.get(creditURL).toPromise();
    console.log(creditsOBJ);
    console.log(creditURL);
    let posterLink = ""
    for(let i=0; i<creditsOBJ.cast.length; i++){
        if(creditsOBJ.cast[i].profile_path)
         posterLink = this.posterBaseURL + creditsOBJ.cast[i].profile_path
        else
          posterLink = "assets/page-not-found.jpg";
        this.dataObject.cast.push( { charName : creditsOBJ.cast[i].character, 
          starName : creditsOBJ.cast[i].name,
          starPosterLink : posterLink
        });
    }
    console.log(this.dataObject.cast)
    this.navigateTo('movie-details')
  }

  async setDataFromTMDB(movieListObj){
    this.clearData();
    //this.movieId = movieListObj.id;
    //TITLE
    this.dataObject.mainTitle =  movieListObj.original_title;
    //RELEASE YEAR
    this.dataObject.titleYear = movieListObj.release_date.split("-")[0];
    //GENRE
    for(let i=0; i<movieListObj.genres.length; i++){
      if(i == movieListObj.genres.length-1)
        this.dataObject.genre += movieListObj.genres[i].name
      else
        this.dataObject.genre += movieListObj.genres[i].name+", "
    }
    //RELEASE DATE
    this.dataObject.releaseDate = movieListObj.release_date;
    //POSTER LINK
    if(movieListObj["poster_path"])
      this.dataObject.posterLink = this.posterBaseURL + movieListObj["poster_path"];
    else
    this.dataObject.posterLink = "assets/page-not-found.jpg";
    
    await this.getCast()
    if(movieListObj.status == "Released"){
      await this.setDatafromOMDB(movieListObj)
    }
    //GETTING VIDEO LINK   
    await this.getVideoLink(movieListObj)
  }

  async getVideoLink(movieListObj){
    //Creating Video Link
    console.log(this.movieId)
    const urlForVideo = this.TMDB_baseURL + this.movieSearch.byID + this.movieId + '/videos' + this.TMDB_api_key;
    //Getting Response from Video Link
    let result = await this.http.get(urlForVideo).toPromise()
    console.log(result)
    //Choosing Video link
    this.chooseVideoLink(result)
  }

  chooseVideoLink(videoObj){
    for(let i=0; i<videoObj.results.length; i++){
        if(videoObj.results[i].site == "YouTube"){
          this.dataObject.videoLink = this.youtubeBaseURL +  videoObj.results[i].key
          break
        }
    }
    console.log(this.dataObject.videoLink)
  }

  clearData(){
    this.dataObject.mainTitle = "";
    this.dataObject.titleYear = "";
    this.dataObject.genre = "";
    this.dataObject.releaseDate = "";
    this.dataObject.imdbRating = "";
    this.dataObject.imdbVotes = "";
    this.dataObject.posterLink = "";    
    this.dataObject.videoLink = "";
    this.dataObject.titlePlot = "The plot is unknown.";
    this.dataObject.metaScore = "";
    this.dataObject.rottenTomatoes = "";
    this.dataObject.awardsReceived = "";
    this.dataObject.directors = "";
    this.dataObject.writers = "";
    this.dataObject.runtime = "";
    this.dataObject.cast = [];
  }

}
