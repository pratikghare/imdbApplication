import { Component, OnInit } from '@angular/core';
import { DataService } from '../datashare/data.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-actors-list',
  templateUrl: './actors-list.component.html',
  styleUrls: ['./actors-list.component.css']
})
export class ActorsListComponent implements OnInit {

  constructor(private myRouter: Router,
    private http : HttpClient, 
    public ds : DataService) { }

  private month = {
    "01" : "Jan",
    "02" : "Feb",
    "03" : "March",
    "04" : "Apr",
    "05" : "May",
    "06" : "June",
    "07" : "July",
    "08" : "Aug",
    "09" : "Sept",
    "10" : "Oct",
    "11" : "Nov",
    "12" : "Dec"
  }

  public actorDetails = {
    name : "",
    birthday : "",
    death : "",
    id : "",
    popularity : "",
    birthPlace : "",
    gender : "",
    profilePath : "",
    biography : "",
    knownFor : "",
    movieList : []
  }

  private movieSearch = {
    byMovie : "/search/movie",
    byID : "/movie/",
    byPersonID : "/person/",
    byTVID : "",
    byActor : "/search/person",
    byTV : "/search/tv",
    similarMovie : "/movie/"+"/similar",
    topRated : "/movie/top_rated",
    upCommingMovies : "/movie/upcoming",
    nowPlaying : "/movie/now_playing"
  }

  public personId = ""
  private TMDB_api_key = "?api_key=e22a6668d441f9ca846239c727eb615e"
  private posterBaseURL = "https://image.tmdb.org/t/p/w500"
  private TMDB_baseURL = "https://api.themoviedb.org/3"


  navigateTo(page){
    this.myRouter.navigate([page])
  }

  ngOnInit(): void {
  }

  async getActorDetails(id){
    this.personId = id;
    const url = this.TMDB_baseURL + this.movieSearch.byPersonID + this.personId + this.TMDB_api_key;
    let personData : any = await this.http.get(url).toPromise()
    console.log(personData)

    this.actorDetails.name = personData.name
    let bday = personData.birthday.split('-').reverse()
    this.actorDetails.birthday = bday[0] + " " + bday[1] + " " + bday[2] 
    if(personData.deathday) this.actorDetails.death = personData.deathday
    this.actorDetails.id = id;
    if(personData.popularity)
      this.actorDetails.popularity = personData.popularity;
    if(personData.place_of_birth)
      this.actorDetails.birthPlace = personData.place_of_birth;
    if(personData.gender)
      this.actorDetails.gender = personData.gender == 1 ? "Female" : "Male";
    if(personData.profile_path)
      this.actorDetails.profilePath = this.posterBaseURL + personData.profile_path
    else
      this.actorDetails.profilePath = "assets/page-not-found.jpg"
    if(personData.biography)  this.actorDetails.biography = personData.biography
    if(personData.known_for_department) this.actorDetails.knownFor = personData.known_for_department
    await this.getMoviesList()
    this.ds.sharePeopleDetails(this.actorDetails)
    this.navigateTo('actor-details')
  }

  async getMoviesList(){
    let url = this.TMDB_baseURL + this.movieSearch.byPersonID + this.personId + "/movie_credits" + this.TMDB_api_key
    let movieListObj : any = await this.http.get(url).toPromise()
    let title = ""
    let year = ""
    let character = ""
    let id = ""
    let posterPath = ""
    for(let i=0; i<movieListObj.cast.length; i++){
      title = ""
      year = ""
      character = ""
      id = ""
      posterPath = ""
      if(movieListObj.cast[i].character) character = movieListObj.cast[i].character
      if(movieListObj.cast[i].title) title = movieListObj.cast[i].title
      else if(movieListObj.cast[i].original_title) title = movieListObj.cast[i]
      if(movieListObj.cast[i].release_date){
        year = movieListObj.cast[i].release_date.split('-')[0]
      }
      if(movieListObj.cast[i].poster_path) posterPath = this.posterBaseURL + movieListObj.cast[i].poster_path
      else posterPath = "assets/page-not-found.jpg"
      id = movieListObj.cast[i].id
      this.actorDetails.movieList.push({
        movieTitle : title,
        year : year,
        character : character,
        posterPath : posterPath,
        movieID : id
      })
    }
  }


  clearData(){

  }
  

}
