import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NavBarComponent } from './nav-bar/nav-bar.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { MovieHomeComponent } from './movie-home/movie-home.component';
import { MovieDetailsComponent } from './movie-details/movie-details.component';
import { MoviesListComponent } from './movies-list/movies-list.component';
import { ActorDetailsComponent } from './actor-details/actor-details.component';
import { ActorsListComponent } from './actors-list/actors-list.component';
import { TvsListComponent } from './tvs-list/tvs-list.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { NewnavbarComponent } from './newnavbar/newnavbar.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { TvDetailsComponent } from './tv-details/tv-details.component';


const routes: Routes = [
  {
    path : "", 
    component : NavBarComponent,
    children : [
      {path : "search-results/movies" , component : MoviesListComponent},
      {path : "search-results/people" , component : ActorsListComponent},
      {path : "search-results/tv" , component : TvsListComponent},
      {path : "movie-details" , component : MovieDetailsComponent},
      {path : "actor-details" , component : ActorDetailsComponent},
      {path : "tv-details", component : TvDetailsComponent},
      {path : "" , component : MovieHomeComponent},
      {path : "error" , component : PagenotfoundComponent},
      
    ]
  },
  {
    path : "home", 
    component : NewnavbarComponent,
    children : [
      {path : "search-results/movies" , component : MoviesListComponent},
      {path : "search-results/people" , component : ActorsListComponent},
      {path : "search-results/tv" , component : TvsListComponent},
      {path : "movie-details" , component : MovieDetailsComponent},
      {path : "actor-details" , component : ActorDetailsComponent},
      {path : "" , component : MovieHomeComponent},
      {path : "tv-details", component : TvDetailsComponent}
    ]
  },
  {path : "login" , component : LoginComponent},
  {path : "register" , component : RegisterComponent},
  {path : "forgot" , component : ForgotPasswordComponent},
  {path : "account-details" , component : AccountDetailsComponent},
  {path : "**" , component : PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
