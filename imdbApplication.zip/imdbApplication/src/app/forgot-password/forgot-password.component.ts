import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  public checkEmail = false
  constructor(private myRouter: Router, private fb: FormBuilder, private http: HttpClient) {

  }

  public fbFormGroup = this.fb.group({
    userEmail: "",
    userPassword: ""
  })

  navigateTo(page) {
    this.myRouter.navigate([page])
  }
  ngOnInit(): void {
    if (sessionStorage.getItem('sid')) {
      this.navigateTo('home')
    }
    else {
    }
  }

  async changePasswordProcess() {
    const updateURL = "http://localhost:3000/updateuser"
    const checkURL = "http://localhost:3000/checkexist"
    const userData = this.fbFormGroup.value
    //console.log(userData)

    let checkResult: any = await this.http.post(checkURL, userData).toPromise()
    if (checkResult.opr) {
      let result: any = await this.http.post(updateURL, userData).toPromise()
      if (result.opr)
        this.navigateTo("login")

    }
    else
      this.checkEmail = true
  }

}
