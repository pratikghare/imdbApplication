import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private myRouter: Router, private http : HttpClient, private fb : FormBuilder) { }

  public fbFormGroup = this.fb.group({
    firstName :  ["" , Validators.required],
    lastName :  ["" , Validators.required],
    userEmail :  ["" ,  [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
    userPassword :  ["" , [Validators.required, Validators.minLength(8), Validators.maxLength(15)]],
    rePass : ["", Validators.required]
  })
  public checkEmail = false
  public checkPass = false
  ngOnInit(): void {
    if (sessionStorage.getItem('sid')) {
      this.navigateTo('home')
    }
    else {
    }
  }

  navigateTo(page){
    this.myRouter.navigate([page])
  }

  async registerProcess(){
    //const checkUrl = "http://localhost:3000/checkexist"
    const addurl = "http://localhost:3000/adduser"
    const userData = this.fbFormGroup.value
    //console.log(userData)
    if(userData.userPassword != userData.rePass){
      this.checkPass = true
      return
    }
    else this.checkPass = false
    //console.log(userData)
    const sendData = { firstName : userData.firstName, lastName : userData.lastName, userEmail : userData.userEmail,
    userPassword : userData.userPassword }
    let result : any = await this.http.post(addurl, sendData).toPromise()
    console.log(result)
    if(result.opr)
      this.navigateTo("login")
    else
      this.checkEmail = true
    /*
    let checkUserExist : any = await this.http.post(checkUrl, userData).toPromise
    if(checkUserExist.opr){
      this.checkEmail = true
      
    }
    else{
      }
    }*/
    
  }
}
