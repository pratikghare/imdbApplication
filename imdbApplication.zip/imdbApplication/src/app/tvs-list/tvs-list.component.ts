import { Component, OnInit } from '@angular/core';
import { DataService } from '../datashare/data.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-tvs-list',
  templateUrl: './tvs-list.component.html',
  styleUrls: ['./tvs-list.component.css']
})
export class TvsListComponent implements OnInit {

  constructor(private myRouter: Router,
    private http: HttpClient,
    public ds: DataService) { }

  private movieSearch = {
    byMovie: "/search/movie",
    byID: "/movie/",
    byPersonID: "/person/",
    byTVID: "/tv/",
    byActor: "/search/person",
    byTV: "/search/tv",
    similarMovie: "/movie/" + "/similar",
    topRated: "/movie/top_rated",
    upCommingMovies: "/movie/upcoming",
    nowPlaying: "/movie/now_playing"
  }

  navigateTo(page) {
    this.myRouter.navigate([page])
  }

  public tvDetails = {
    title: "",
    genre: "",
    titleYear: "",
    imdbRating: "",
    imdbVotes: "",
    releaseDate: "",
    posterLink: "",
    videoLink: "",
    plot: "",
    metaScore: "",
    rottenTomatoes: "",
    awardsReceived: "",
    director: "",
    writers: "",
    runtime : "",
    seasons: [],
    cast: []
  }

  public tvID = ""
  private OMDB_baseURL = "http://www.omdbapi.com/?apikey=f9ecc56a&"
  private TMDB_api_key = "?api_key=e22a6668d441f9ca846239c727eb615e"
  private posterBaseURL = "https://image.tmdb.org/t/p/w500"
  private youtubeBaseURL = "https://www.youtube.com/embed/"
  private TMDB_baseURL = "https://api.themoviedb.org/3"

  ngOnInit(): void {
  }

  async getTVDetails(id) {
    this.tvID = id;
    const url = this.TMDB_baseURL + this.movieSearch.byTVID + this.tvID + this.TMDB_api_key
    console.log(url)
    const tvListObj: any = await this.http.get(url).toPromise();
    console.log(tvListObj)
    await this.setDataFromTMDB(tvListObj)
    console.log('MAIN DATA')
    console.log(this.tvDetails)
    this.ds.shareTVDetails(this.tvDetails)
    this.navigateTo('tv-details')
  }

  async setDataFromTMDB(tvListObj) {
    this.clearData();
    //TITLE
    if (tvListObj.original_name)
      this.tvDetails.title = tvListObj.original_name;
    else if (tvListObj.name)
      this.tvDetails.title = tvListObj.name;
    //TITLE YEAR
    this.tvDetails.titleYear = tvListObj.first_air_date.split("-")[0];
    //GENRE
    for (let i = 0; i < tvListObj.genres.length; i++) {
      if (i == tvListObj.genres.length - 1)
        this.tvDetails.genre += tvListObj.genres[i].name
      else
        this.tvDetails.genre += tvListObj.genres[i].name + ", "
    }
    //WRITERS
    for (let i = 0; i < tvListObj.created_by.length; i++) {
      if (i == tvListObj.created_by.length - 1)
        this.tvDetails.writers += tvListObj.created_by[i].name
      else
        this.tvDetails.writers += tvListObj.created_by[i].name + ", "
    }
    //PLOT
    if (tvListObj.poster_path)
      this.tvDetails.posterLink = this.posterBaseURL + tvListObj.poster_path
    //SEASONS
    if (tvListObj.seasons) {
      let year = ""
      let poster = ""
      let name = ""
      let no = ""
      for (let i = 0; i < tvListObj.seasons.length; i++) {
        year = ""
        poster = ""
        name = ""
        no = ""
        if (tvListObj.seasons[i].name) name = tvListObj.seasons[i].name
        if (tvListObj.seasons[i].air_date) year = tvListObj.seasons[i].air_date.split('-')[0]
        if (tvListObj.seasons[i].poster_path) poster = this.posterBaseURL + tvListObj.seasons[i].poster_path
        else poster = "assets/page-not-found.jpg"
        if (tvListObj.seasons[i].season_number) no = tvListObj.seasons[i].season_number
        this.tvDetails.seasons.push({
          title: name,
          posterLink: poster,
          year: year,
          num : no
        })
      }
    }
    await this.getCast()
    await this.setDataFromOMDB()
    await this.getVideoLink()
  }

  async getVideoLink(){
    const url = this.TMDB_baseURL + this.movieSearch.byTVID + this.tvID + "/videos" + this.TMDB_api_key
    let result = await this.http.get(url).toPromise()
    console.log(result)
    //Choosing Video link
    this.chooseVideoLink(result)
  }

  chooseVideoLink(videoObj){
    for(let i=0; i<videoObj.results.length; i++){
        if(videoObj.results[i].site == "YouTube"){
          this.tvDetails.videoLink = this.youtubeBaseURL +  videoObj.results[i].key
          break
        }
    }
    console.log(this.tvDetails.videoLink)
  }


  async getCast() {
    const creditURL = this.TMDB_baseURL + this.movieSearch.byTVID + this.tvID + "/credits" + this.TMDB_api_key;
    const creditsOBJ: any = await this.http.get(creditURL).toPromise();
    console.log(creditsOBJ);
    console.log(creditURL);
    let posterLink = ""
    for (let i = 0; i < creditsOBJ.cast.length; i++) {
      if (creditsOBJ.cast[i].profile_path)
        posterLink = this.posterBaseURL + creditsOBJ.cast[i].profile_path
      else
        posterLink = "assets/page-not-found.jpg";
      this.tvDetails.cast.push({
        charName: creditsOBJ.cast[i].character,
        starName: creditsOBJ.cast[i].name,
        starPosterLink: posterLink,
        id : creditsOBJ.cast[i].id
      });
    }
  }


  async setDataFromOMDB() {
    //Getting IMDB ID
    const extIDURL = this.TMDB_baseURL + this.movieSearch.byTVID + this.tvID + "/external_ids" + this.TMDB_api_key
    console.log(extIDURL)
    const extIDResult = await this.http.get(extIDURL).toPromise()
    const imdbID = extIDResult["imdb_id"]
    //Getting Movie Details from OMDB
    const userOMDBurl = this.OMDB_baseURL + "i=" + imdbID
    const omdbDATA: any = await this.http.get(userOMDBurl).toPromise()
    if (!omdbDATA) return
    console.log('OMDB DATA')
    console.log(omdbDATA)
    //IMDB RATING
    this.tvDetails.imdbRating = omdbDATA.Ratings[0].Value.split('/')[0];
    //console.log(this.tvDetails.imdbRating)
    //IMDB VOTES
    this.tvDetails.imdbVotes = omdbDATA.imdbVotes;
    //console.log(this.tvDetails.imdbVotes)
    //PLOT
    if (omdbDATA.Plot != "N/A")
      this.tvDetails.plot = omdbDATA.Plot;
    //console.log(this.tvDetails.titlePlot)
    //META SCORE
    if (omdbDATA.Metascore != "N/A")
      this.tvDetails.metaScore = omdbDATA.Metascore;
    //console.log(this.tvDetails.metaScore)
    //ROTTEN TOMATOES
    if (omdbDATA.Ratings.length > 1)
      this.tvDetails.rottenTomatoes = omdbDATA.Ratings[1].Value;
    //console.log(this.tvDetails.rottenTomatoes)
    //AWARDS RECEIVED
    if (omdbDATA.Awards != "N/A")
      this.tvDetails.awardsReceived = omdbDATA.Awards;
    //console.log(this.tvDetails.awardsReceived)
    if (omdbDATA.Director != "N/A")
      this.tvDetails.director = omdbDATA.Director;
    if (omdbDATA.Writer != "N/A")
      this.tvDetails.writers = omdbDATA.Writer;
    if (omdbDATA.Released != "N/A")
      this.tvDetails.releaseDate = omdbDATA.Released;
    console.log('ALL DATA SET')
    //await this.getCast()
  }


  clearData() {
    this.tvDetails.title = "";
    this.tvDetails.genre = "";
    this.tvDetails.titleYear = "";
    this.tvDetails.imdbRating = "";
    this.tvDetails.imdbVotes = "";
    this.tvDetails.releaseDate = "";
    this.tvDetails.posterLink = "";
    this.tvDetails.videoLink = "";
    this.tvDetails.plot = "";
    this.tvDetails.metaScore = "";
    this.tvDetails.rottenTomatoes = "";
    this.tvDetails.awardsReceived = "";
    this.tvDetails.director = "";
    this.tvDetails.writers = "";
    this.tvDetails.seasons = [];
    this.tvDetails.cast = []
  }

}
