import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  public userData : any = {}
  public movieList = []
  public peopleList = []
  public TVList = []
  public peopleData : any = {}
  public tvDetails : any = {} 
  public popularData = []
  public posterBaseURL = "https://image.tmdb.org/t/p/w500"
  constructor() { }
  
  
  public userName = "User"
  public email = ""
  public lastName = ""

  shareMovieDetails(obj){
    this.userData = {}
    this.userData = obj
    //console.log("DATA FROM SERVICE")
    //console.log(this.userData)
  }
  public showbtn = false

  shareMovieList(list){
    this.movieList = []
    this.movieList = list;
    //console.log("DATA FROM SERVICE")
    //console.log(this.movieList)
  }

  sharePeopleList(list){
    this.peopleList = []
    this.peopleList = list
    //console.log("DATA FROM SERVICE")
    //console.log(this.peopleList)
  }

  sharePeopleDetails(obj){
    this.peopleData = {}
    this.peopleData = obj;
    //console.log("DATA FROM SERVICE")
   // console.log(this.peopleData)
  }

  shareUserInfo(obj){
    console.log(obj)
    //if(obj.firstName)
      this.userName = obj.firstName
    //if(obj.obj.userEmail)
    this.email = obj.userEmail
    //if(obj.lastName)
      this.lastName = obj.lastName
  }

  shareTVList(list){
    this.TVList = []
    this.TVList = list
    console.log('DATA SERVICE')
    console.log(this.TVList)
  }

  clearUserData(){
    this.userName = "User"
    this.email = ""
    this.lastName = ""
  }

  shareTVDetails(obj){
    this.tvDetails = {}
    this.tvDetails = obj
    console.log('FROM SERVICE')
    console.log(this.tvDetails)
  }

/*
  async getPopular(){
    const url = "https://api.themoviedb.org/3/movie/popular?api_key=e22a6668d441f9ca846239c727eb615e&language=en-US"
    let result : any = await this.http.get(url).toPromise()
    console.log(result)
    for(let i=0; i<20; i++){
      let id = ""
      let title = ""
      let poster = ""
      let vote = "" 
      id = result.results[i].id;
      title = result.results[i].title
      if(result.results[i].poster_path) poster = this.posterBaseURL + result.results[i].poster_path;
      else poster = "assets/page-not-found.jpg"
      vote = result.results[i].vote_count
      this.popularData.push({
        id : id,
        title : title,
        posterLink : poster,
        vote : vote
      })
    }
  }*/
}
