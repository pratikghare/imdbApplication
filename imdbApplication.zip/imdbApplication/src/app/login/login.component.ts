import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../datashare/data.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor (private myRouter: Router, private http : HttpClient, private fb : FormBuilder, public ds : DataService) {
    
  }
  public logErr = false;
  public fbFormGroup = this.fb.group({
    userEmail : ["", [Validators.required, Validators.email]],
    userPassword : ["", [Validators.required]]
  })

  navigateTo(page){
    this.myRouter.navigate([page])
  }

  async loginProcessHere(){
    const userData = this.fbFormGroup.value
    const url = "http://localhost:3000/checkuser"
    const result : any = await this.http.post(url, userData).toPromise()
    console.log(result.opr)
    if(result.opr){
      sessionStorage.setItem('sid', 'true')
      this.ds.shareUserInfo(result)
      this.navigateTo('home/')
    }
    else{
      this.logErr = true
    }
  }

  ngOnInit(): void {
    if (sessionStorage.getItem('sid')) {
      this.navigateTo('home')
    }
    else {
    }
  }

}
