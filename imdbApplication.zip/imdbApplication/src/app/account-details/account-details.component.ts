import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../datashare/data.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  constructor(private myRouter: Router, private fb : FormBuilder, public ds : DataService, private http: HttpClient) { }

  

  logoutProcess(){
    if(sessionStorage.getItem('sid')){
      sessionStorage.removeItem('sid')
      this.navigateTo('login')
    }
  }

  ngOnInit(): void {
    if(!sessionStorage.getItem('sid')){
      this.navigateTo('login')
    }
    else{
    }
  }
  
  navigateTo(page){
    this.myRouter.navigate([page])
  }

}
