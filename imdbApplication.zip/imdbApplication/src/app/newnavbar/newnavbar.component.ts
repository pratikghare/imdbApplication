import { Component, OnInit } from '@angular/core';
import { faSearch } from '@fortawesome/free-solid-svg-icons';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../datashare/data.service';

@Component({
  selector: 'app-newnavbar',
  templateUrl: './newnavbar.component.html',
  styleUrls: ['./newnavbar.component.css']
})
export class NewnavbarComponent implements OnInit {
  public searchPlaceholder = "Search for Movies..."
  public selectedQuery = "Movies"
  public accountBtn = true
  public faSearch = faSearch
  public movieId = ""
  public movieSearch = {
    byMovie: "/search/movie",
    byID: "/movie/",
    byActor: "/search/person",
    byTV: "/search/tv",
    similarMovie: "/movie/" + "/similar",
    topRated: "/movie/top_rated",
    upCommingMovies: "/movie/upcoming",
    nowPlaying: "/movie/now_playing"
  }
  public movieList = []
  public actorList = []
  public seriesList = []
  private TMDB_api_key = "?api_key=e22a6668d441f9ca846239c727eb615e"
  private posterBaseURL = "https://image.tmdb.org/t/p/w500"
  private TMDB_baseURL = "https://api.themoviedb.org/3"
  route: ActivatedRoute;

  constructor(private myRouter: Router, private http: HttpClient, private fb: FormBuilder, public ds: DataService) {

  }
  //https://api.themoviedb.org/3/movie/299534?api_key=e22a6668d441f9ca846239c727eb615e

  public fbFormGroup = this.fb.group({
    userSearchQuery: ["", Validators.required]
  })

  logoutProcess() {
    if (sessionStorage.getItem('sid')) {
      sessionStorage.removeItem('sid')
      this.navigateTo('login')
    }
  }

  ngOnInit(): void {
    if (!sessionStorage.getItem('sid')) {
      this.navigateTo('')
    }
    else {
    }
  }
  navigateTo(page) {
    this.myRouter.navigate([page], { relativeTo: this.route })
  }
  changeQuerry(event: any) {
    this.selectedQuery = event.target.textContent
    this.searchPlaceholder = "Search for " + this.selectedQuery + "..."
  }
  searchProcessing() {
    if (this.selectedQuery == "Movies") {
      this.searchForMovie()
    }
    else if (this.selectedQuery == "TV Series") {
      this.searchForTV()
    }
    else if (this.selectedQuery == "Actors") {
      this.searchForActors()
    }
  }


  async searchForMovie() {
    this.movieList = []
    this.actorList = []
    console.log(this.fbFormGroup.value)
    const query = "&query=" + this.fbFormGroup.value.userSearchQuery
    this.fbFormGroup.setValue({
      userSearchQuery: ""
    })
    const url = this.TMDB_baseURL + this.movieSearch.byMovie + this.TMDB_api_key + query
    console.log(url)
    const movieListObj: any = await this.http.get(url).toPromise();
    console.log(movieListObj.results)




    let posterPath = ""
    let year = ""
    for (let i = 0; i < movieListObj.results.length; i++) {
      if (movieListObj.results[i].poster_path)
        posterPath = this.posterBaseURL + movieListObj.results[i].poster_path
      else
        posterPath = "assets/page-not-found.jpg"

      if (movieListObj.results[i].release_date)
        year = movieListObj.results[i].release_date.split('-')[0]
      this.movieList.push({
        id: movieListObj.results[i].id,
        movieTitle: movieListObj.results[i].title,
        year: year,
        posterLink: posterPath
      })
    }
    console.log(this.movieList)
    console.log(this.movieList.length)
    if(this.movieList.length != 0)
      {
        this.ds.shareMovieList(this.movieList)
        this.navigateTo('search-results/movies')
      }
    else
      this.navigateTo('error')
  }

  async searchForActors() {
    this.movieList = []
    this.actorList = []
    console.log(this.fbFormGroup.value, this.actorList)
    const query = "&query=" + this.fbFormGroup.value.userSearchQuery
    this.fbFormGroup.setValue({
      userSearchQuery: ""
    })
    const url = this.TMDB_baseURL + this.movieSearch.byActor + this.TMDB_api_key + query
    console.log(url)
    const movieListObj: any = await this.http.get(url).toPromise();
    console.log(movieListObj.results)

    let posterPath = ""
    let year = ""
    for (let i = 0; i < movieListObj.results.length; i++) {
      if (movieListObj.results[i].profile_path)
        posterPath = this.posterBaseURL + movieListObj.results[i].profile_path
      else
        posterPath = "assets/page-not-found.jpg"

      if (movieListObj.results[i].release_date)
        year = movieListObj.results[i].release_date.split('-')[0]
      this.actorList.push({
        id: movieListObj.results[i].id,
        movieTitle: movieListObj.results[i].name,
        year: year,
        posterLink: posterPath
      })
    }
    console.log(this.actorList.length)
    if(this.actorList.length != 0){
      this.ds.sharePeopleList(this.actorList)
      this.navigateTo('search-results/people')
    }
    else
      this.navigateTo('error')
  }

  async searchForTV() {
    this.movieList = []
    this.actorList = []
    this.seriesList = []
    console.log(this.fbFormGroup.value, this.actorList)
    const query = "&query=" + this.fbFormGroup.value.userSearchQuery
    this.fbFormGroup.setValue({
      userSearchQuery: ""
    })
    const url = this.TMDB_baseURL + this.movieSearch.byTV + this.TMDB_api_key + query
    console.log(url)
    const seriesListObj : any = await this.http.get(url).toPromise();
    //console.log(seriesListObj)
    let seriesID = ""
    let seriesTitle = ""
    let seriesPoster = ""
    for(let i=0; i<seriesListObj.results.length; i++){
      seriesID = ""
      seriesTitle = ""
      seriesPoster = ""
      if(seriesListObj.results[i].original_name)  seriesTitle = seriesListObj.results[i].original_name
      if(seriesListObj.results[i].id) seriesID = seriesListObj.results[i].id
      if(seriesListObj.results[i].poster_path)  seriesPoster = seriesListObj.results[i].poster_path
      this.seriesList.push({
        id: seriesID,
        title : seriesTitle,
        posterPath : seriesPoster
      })
    }

    //console.log(this.seriesList)
    if(this.seriesList.length != 0){
      this.ds.shareTVList(this.seriesList)
      this.navigateTo('search-results/tv')
    }
    else
      this.navigateTo('error')
  }
}
