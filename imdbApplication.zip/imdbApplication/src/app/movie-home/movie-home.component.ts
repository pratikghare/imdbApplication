import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
import { faSearch } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-movie-home',
  templateUrl: './movie-home.component.html',
  styleUrls: ['./movie-home.component.css']
})
export class MovieHomeComponent implements OnInit {

  constructor(private myRouter: Router, private http : HttpClient, private fb : FormBuilder) { }

  public faSearch = faSearch
  
  ngOnInit(): void {
    this.getTopRated()
    this.getNowPlaying()
    this.getUpcomming()

  }

  

  getTopRated(){

  }

  getNowPlaying(){

  }
  
  getUpcomming(){

  }

  navigateTo(page){
    this.myRouter.navigate([page])
  }
}
