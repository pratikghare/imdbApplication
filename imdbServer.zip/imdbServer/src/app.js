let Promise = require('bluebird')
let express = require('express')
let mysql = require('mysql')
let app = express()
let cors = require('cors')
let  { check , validationResult } = require('express-validator');
const Joi = require('@hapi/joi')

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

//Body params to JSON
app.use(express.json())

//Ublocking CORS policy
app.use(cors())

let DB_INFO = {
    host : "localhost",
    user : "root",
    password : "pratik@123",
    database : "imdbapp"
}

let authSchema = Joi.object({
  firstName : Joi.string().required(),
  lastName : Joi.string().required(),
  userEmail : Joi.string().lowercase().email().required(),
  userPassword : Joi.string().min(8).max(15)
})



let checkUser = async (input) => {
    const connection = mysql.createConnection(DB_INFO);
    await connection.connectAsync();
    
    let myQuery =
      "select * from users where email = ? and password = ?";
      const result = await connection.queryAsync(myQuery, [
        input.userEmail,
        input.userPassword,
    ]);
    console.log('Result ' , result)
    await connection.endAsync();
    if(result.length === 0){
      throw new Error("Invalid credentials")
    }
    return result
};

app.post("/checkuser", async (req, res) => {
    try {
      const input = req.body; 
        console.log(input)
      let userData = await checkUser(input);
      //console.log(userData[0].email)
      const email = userData[0].email;
      const fname = userData[0].first_name;
      const lname = userData[0].last_name;
      res.json({opr : true, firstName : fname, lastName : lname, userEmail : email});
    } 
    catch (err) {
      res.json({ opr : false });
    }
});

let addUser = async (input) => {
    const connection = mysql.createConnection(DB_INFO);
    await connection.connectAsync();
    
    let myQuery =
      "insert into users (first_name, last_name, email, password) values(? , ? , ? , ?)"
      await connection.queryAsync(myQuery, [
        input.firstName,
        input.lastName,
        input.userEmail,
        input.userPassword,
    ]);
    await connection.endAsync();
    //if(result.length === 0){
      //throw new Error("Invalid credentials")
    //}   
}

app.post("/adduser", async (req, res) => {
  //let result = {}
    try{
        let userData = req.body;
        console.log(req.body)
        //result = await authSchema.validateAsync(req.body)
        //console.log(result)
        //console.log(userData);
        await addUser(userData);
        res.json({ opr : true  });
    }
    catch(err){
      console.log('Error')
        res.json({ opr : false });
    }
})

app.get("/getfiles" , (req, res) => {
    res.send({ message : "success"})
})

let checkIfUserExist = async (input) => {
    const connection = mysql.createConnection(DB_INFO);
    await connection.connectAsync();
    
    let myQuery =
      "select * from users where email = ?";
      const result = await connection.queryAsync(myQuery, [
        input.userEmail
    ]);
    await connection.endAsync();
    if(result.length === 0){
      throw new Error("Invalid credentials")
    }
};

app.post("/checkexist", async (req, res) => {
    try{
        let userData = req.body;
        console.log(userData);
        await checkIfUserExist(userData);
        res.json({ opr : true });
    }
    catch(err){
        res.json({ opr : false });
    }
})

let forgotPass = async (input) => {
  const connection = mysql.createConnection(DB_INFO);
    await connection.connectAsync();
    
    let myQuery =
      "update users set password = ? where email = ?";
      const result = await connection.queryAsync(myQuery, [
        input.userPassword,
        input.userEmail
    ]);
    await connection.endAsync();
    console.log(result, result.length)
    if(result.length === 0){
      throw new Error("Invalid credentials")
    }
}


app.post("/updateuser", async (req, res) => {
  try {
    const input = req.body; 
      console.log(input)
    await forgotPass(input);
    res.json({ opr : true });
  } 
  catch (err) {
    res.json({ opr : false });
  }
});

app.post("/deleteuser", async (req, res) => {
  try {
    const input = req.body; 
      console.log(input)
    await deleteUser(input);
    res.json({ opr : true });
  } 
  catch (err) {
    res.json({ opr : false });
  }
});

let deleteUser = async (input) => {
  await checkUser(input)
  const connection = mysql.createConnection(DB_INFO);
  await connection.connectAsync();
  let myQuery =
    "delete from users where email = ?"
    await connection.queryAsync(myQuery, input.userEmail);
  await connection.endAsync();
  //if(result.length === 0){
    //throw new Error("Invalid credentials")
  //}
}

let updateUser = async (input) => {
  await checkUser(input)
  const connection = mysql.createConnection(DB_INFO);
  await connection.connectAsync();
  let myQuery = "update users set first_name = ?, last_name = ?, password = ? where email = ?"
    await connection.queryAsync(myQuery, [
      input.firstName,
      input.lastName,
      input.userEmail,
      input.userPassword,
  ]);
  await connection.endAsync();
  //if(result.length === 0){
    //throw new Error("Invalid credentials")
  //}
}

app.post('/updatedetails' , (req, res) => {
  try {
    const input = req.body; 
    console.log(input)
    //await updateUser(input);
    
    res.json({ opr : true });
  } 
  catch (err) {
    res.json({ opr : false });
  }
})

  
app.listen(3000)